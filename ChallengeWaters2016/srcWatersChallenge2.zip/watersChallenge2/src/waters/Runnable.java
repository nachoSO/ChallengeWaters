package waters;

public class Runnable {
	String name;
	int nInstructions;
	double executionTime;
	double responseTime; //reaction
	int numReads=0; //numReads*9
	int numWrites=0;
	
	public Runnable(String name,int nInstructions,int numReads, int numWrites){
		this.name=name;
		this.nInstructions=nInstructions;
		this.responseTime=0;
		this.numReads=numReads+8+(1*4);
		this.numWrites=numWrites+8+(1*4);
		this.executionTime=((this.nInstructions/350000000.0)*(1000000.0))+numReads+numWrites; // (n/f)*usec;

	}
	
	public String toString(){
		return "Runnable name: "+name+", nInstructions: "+nInstructions +", executionTime: "+executionTime;
	}
	
}
